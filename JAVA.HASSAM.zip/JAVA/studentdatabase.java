public class StudentDatabase {
    public static void main(String[] args) {
        String name = "Hassam";
        int age = 20;
        double gpa = 3.8;
        char gender = 'M';
        boolean isForeigner = false;
        String studentId = "0001";

        System.out.println("Student Information:");
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("GPA: " + gpa);
        System.out.println("Gender: " + gender);
        System.out.println("Foreigner: " + isForeigner);
        System.out.println("Student ID: " + studentId);
    }
}
