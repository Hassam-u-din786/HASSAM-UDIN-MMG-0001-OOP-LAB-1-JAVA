import java.util.Scanner;

public class CurrencyConverter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input for USD to PKR conversion rate
        System.out.print("Enter the conversion rate from USD to PKR: ");
        double conversionRate = scanner.nextDouble();

        // Input for amount in USD
        System.out.print("Enter the amount in USD: ");
        double usdrs = scanner.nextDouble();

        // Convert USD to PKR
        double rupees = usdrs * conversionRate;

        // Output the result
        System.out.println("Equivalent amount in PKR: " + rupees);
    }
}
